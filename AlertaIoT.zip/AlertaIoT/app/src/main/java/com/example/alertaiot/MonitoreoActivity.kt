package com.example.alertaiot

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MonitoreoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Sesion.iniciada) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        setContentView(R.layout.activity_monitoreo)

        val distancia = findViewById<TextView>(R.id.tvDistancia)
        val estado = findViewById<TextView>(R.id.tvEstado)
        val actualizar = findViewById<Button>(R.id.btnActualizar)
        val volver = findViewById<Button>(R.id.btnVolver)

        actualizar.setOnClickListener {
            val valor = Random.nextInt(1, 101)

            distancia.text = getString(R.string.formato_distancia_cm, valor)

            val prefs = getSharedPreferences("config_iot", MODE_PRIVATE)
            val alertas = prefs.getBoolean("alertas", true)
            val umbral = prefs.getInt("umbral", 30)
            when {
                !alertas -> {
                    estado.text = getString(R.string.estado_alertas_desactivadas_monitoreo)
                    estado.setTextColor(getColor(R.color.iot_text))
                }
                valor < (umbral / 2) -> {
                    estado.text = getString(R.string.estado_peligro)
                    estado.setTextColor(getColor(R.color.iot_red))
                }

                valor < umbral -> {
                    estado.text = getString(R.string.estado_precaucion)
                    estado.setTextColor(getColor(android.R.color.holo_orange_dark))
                }

                else -> {
                    estado.text = getString(R.string.estado_seguro)
                    estado.setTextColor(getColor(R.color.iot_green))
                }
            }
        }

        volver.setOnClickListener {
            finish()
        }
    }
}
