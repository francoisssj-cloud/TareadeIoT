package com.example.alertaiot

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Sesion.iniciada) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        setContentView(R.layout.activity_main)

        val monitoreo = findViewById<Button>(R.id.btnMonitoreo)
        val activador = findViewById<Button>(R.id.btnActivador)
        val salir = findViewById<Button>(R.id.btnSalir)

        monitoreo.setOnClickListener {
            startActivity(Intent(this, MonitoreoActivity::class.java))
        }

        activador.setOnClickListener {
            startActivity(Intent(this, ActivadorActivity::class.java))
        }

        salir.setOnClickListener {
            Sesion.iniciada = false
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }
    }
}
