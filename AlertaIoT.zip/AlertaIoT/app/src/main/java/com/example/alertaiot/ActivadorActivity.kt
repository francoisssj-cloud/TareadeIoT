package com.example.alertaiot

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider

class ActivadorActivity : AppCompatActivity() {

    private var isMqttConnected: Boolean = false

    private lateinit var switchAlerta: MaterialSwitch
    private lateinit var tvEstadoAlerta: TextView
    private lateinit var seekUmbral: Slider
    private lateinit var tvUmbral: TextView
    private lateinit var btnAplicar: Button
    private lateinit var btnVolverActivador: Button

    private lateinit var tvEstadoConexion: TextView
    private lateinit var ivIconoConexion: ImageView
    private lateinit var cardConexion: MaterialCardView
    private lateinit var btnSimularConexion: MaterialButton
    private lateinit var vIndicadorAlerta: View
    private lateinit var cardFeedback: MaterialCardView
    private lateinit var tvMensajeFeedback: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Sesion.iniciada) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        setContentView(R.layout.activity_activador)

        // Inicialización de vistas con los identificadores obligatorios
        switchAlerta = findViewById(R.id.switchAlerta)
        tvEstadoAlerta = findViewById(R.id.tvEstadoAlerta)
        seekUmbral = findViewById(R.id.seekUmbral)
        tvUmbral = findViewById(R.id.tvUmbral)
        btnAplicar = findViewById(R.id.btnAplicar)
        btnVolverActivador = findViewById(R.id.btnVolverActivador)

        // Vistas adicionales de estado e interfaz
        tvEstadoConexion = findViewById(R.id.tvEstadoConexion)
        ivIconoConexion = findViewById(R.id.ivIconoConexion)
        cardConexion = findViewById(R.id.cardConexion)
        btnSimularConexion = findViewById(R.id.btnSimularConexion)
        vIndicadorAlerta = findViewById(R.id.vIndicadorAlerta)
        cardFeedback = findViewById(R.id.cardFeedback)
        tvMensajeFeedback = findViewById(R.id.tvMensajeFeedback)

        // Carga de configuración persistente local
        val prefs = getSharedPreferences("config_iot", MODE_PRIVATE)
        val alertasGuardadas = prefs.getBoolean("alertas", true)
        val umbralGuardado = prefs.getInt("umbral", 30)

        switchAlerta.isChecked = alertasGuardadas
        seekUmbral.value = umbralGuardado.coerceIn(0, 100).toFloat()
        tvUmbral.text = getString(R.string.formato_distancia_cm, umbralGuardado)

        actualizarEstadoVisualAlerta(alertasGuardadas)
        actualizarEstadoConexion()

        // Evento cambio de switch
        switchAlerta.setOnCheckedChangeListener { _, activo ->
            actualizarEstadoVisualAlerta(activo)
        }

        // Evento cambio de slider
        seekUmbral.addOnChangeListener { _, value, _ ->
            val progress = value.toInt()
            tvUmbral.text = getString(R.string.formato_distancia_cm, progress)
        }

        // Evento botón simular conexión MQTT
        btnSimularConexion.setOnClickListener {
            isMqttConnected = !isMqttConnected
            actualizarEstadoConexion()
            val estadoTexto = if (isMqttConnected) "CONECTADO A BROKER MQTT" else "DESCONECTADO (MODO LOCAL)"
            mostrarFeedback("Estado de conexión: $estadoTexto", esError = !isMqttConnected)
        }

        // Evento botón Aplicar Configuración
        btnAplicar.setOnClickListener {
            val activo = switchAlerta.isChecked
            val valor = seekUmbral.value.toInt()

            // Guardar configuración localmente en SharedPreferences
            prefs.edit().putBoolean("alertas", activo).putInt("umbral", valor).apply()

            if (isMqttConnected) {
                val topic = "iot/proximidad/config"
                val payload = "{\"alertas\": $activo, \"umbral\": $valor}"
                publicarComandoMQTT(topic, payload)

                val mensaje = "Comando MQTT enviado ($topic): alertas=$activo, umbral=$valor cm"
                mostrarFeedback(mensaje, esError = false)
                Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show()
            } else {
                val mensaje = if (activo) {
                    "Configuración guardada localmente ($valor cm). Sin conexión MQTT remota activa."
                } else {
                    "Alertas desactivadas localmente. Sin conexión MQTT remota activa."
                }
                mostrarFeedback(mensaje, esError = false)
                Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show()
            }
        }

        // Evento botón Volver
        btnVolverActivador.setOnClickListener {
            finish()
        }
    }

    private fun actualizarEstadoVisualAlerta(activo: Boolean) {
        if (activo) {
            tvEstadoAlerta.text = getString(R.string.estado_alertas_activadas)
            tvEstadoAlerta.setTextColor(ContextCompat.getColor(this, R.color.iot_text_primary))
            vIndicadorAlerta.backgroundTintList = ContextCompat.getColorStateList(this, R.color.iot_status_connected)
        } else {
            tvEstadoAlerta.text = getString(R.string.estado_alertas_desactivadas)
            tvEstadoAlerta.setTextColor(ContextCompat.getColor(this, R.color.iot_text_secondary))
            vIndicadorAlerta.backgroundTintList = ContextCompat.getColorStateList(this, R.color.iot_text_secondary)
        }
    }

    private fun actualizarEstadoConexion() {
        if (isMqttConnected) {
            tvEstadoConexion.text = getString(R.string.estado_conexion_conectado)
            tvEstadoConexion.setTextColor(ContextCompat.getColor(this, R.color.iot_status_connected))
            ivIconoConexion.imageTintList = ContextCompat.getColorStateList(this, R.color.iot_status_connected)
            cardConexion.setCardBackgroundColor(ContextCompat.getColor(this, R.color.iot_status_connected_bg))
            cardConexion.strokeColor = ContextCompat.getColor(this, R.color.iot_status_connected)
            btnSimularConexion.text = getString(R.string.btn_simular_desconexion)
        } else {
            tvEstadoConexion.text = getString(R.string.estado_conexion_desconectado)
            tvEstadoConexion.setTextColor(ContextCompat.getColor(this, R.color.iot_status_disconnected))
            ivIconoConexion.imageTintList = ContextCompat.getColorStateList(this, R.color.iot_status_disconnected)
            cardConexion.setCardBackgroundColor(ContextCompat.getColor(this, R.color.iot_status_disconnected_bg))
            cardConexion.strokeColor = ContextCompat.getColor(this, R.color.iot_status_disconnected)
            btnSimularConexion.text = getString(R.string.btn_simular_conexion)
        }
    }

    private fun mostrarFeedback(mensaje: String, esError: Boolean) {
        tvMensajeFeedback.text = mensaje
        val colorFondo = if (esError) R.color.iot_status_disconnected_bg else R.color.iot_blue_container
        val colorBorde = if (esError) R.color.iot_status_disconnected else R.color.iot_blue_medium
        val colorTexto = if (esError) R.color.iot_status_disconnected else R.color.iot_blue_primary

        cardFeedback.setCardBackgroundColor(ContextCompat.getColor(this, colorFondo))
        cardFeedback.strokeColor = ContextCompat.getColor(this, colorBorde)
        tvMensajeFeedback.setTextColor(ContextCompat.getColor(this, colorTexto))
    }

    /**
     * Método preparado para el envío remoto de comandos por MQTT.
     */
    @Suppress("UNUSED_PARAMETER")
    private fun publicarComandoMQTT(topic: String, payload: String) {
        // En una implementación con cliente MQTT real (ej. Eclipse Paho o HiveMQ Client):
        // mqttClient?.publish(topic, payload.toByteArray(), 1, false)
    }
}
