package com.example.alertaiot

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val usuario = findViewById<EditText>(R.id.etUsuario)
        val password = findViewById<EditText>(R.id.etPassword)
        val login = findViewById<Button>(R.id.btnLogin)
        val error = findViewById<TextView>(R.id.tvError)

        login.setOnClickListener {
            val user = usuario.text.toString().trim()
            val pass = password.text.toString()

            when {
                user.isEmpty() || pass.isEmpty() -> {
                    error.text = getString(R.string.error_campos_vacios)
                    error.visibility = View.VISIBLE
                }

                user == "admin" && pass == "1234" -> {
                    error.visibility = View.GONE
                    Sesion.iniciada = true
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                }

                else -> {
                    error.text = getString(R.string.error_credenciales_incorrectas)
                    error.visibility = View.VISIBLE
                }
            }
        }
    }
}
