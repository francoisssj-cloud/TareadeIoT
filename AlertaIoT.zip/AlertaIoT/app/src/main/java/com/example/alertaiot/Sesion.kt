package com.example.alertaiot

/** Sesión local temporal para la demostración; no reemplaza autenticación real. */
object Sesion {
    var iniciada: Boolean = false
}
