# Alerta IoT — prototipo Android (corregido)

Proyecto Kotlin/XML. Se corrigió el `AndroidManifest.xml` para iniciar en Login y registrar las cuatro Activities, y se unificó el tema de modo nocturno. Se añadió sesión temporal en memoria y se guardan localmente las preferencias del activador. Monitoreo utiliza estas preferencias para clasificar lecturas simuladas.

## Ejecución
1. Abrir esta carpeta con Android Studio.
2. Esperar la sincronización Gradle y ejecutar en un emulador API 26+.
3. Login de demostración: `admin` / `1234` (NO apto para producción).
4. Probar Monitoreo, Activador, volver y cerrar sesión.

## Pendiente para cumplir la evaluación
- Comunicación real entre dos emuladores por Wi-Fi/MQTT, recepción de mensajes y confirmaciones.
- Autenticación segura, TLS y gestión de secretos.
- Pruebas de interconexión y documentación ISO/IEC 27400 y seguridad OT.

**No se afirma cumplimiento de la rúbrica completa ni compilación validada en Android Studio.**
